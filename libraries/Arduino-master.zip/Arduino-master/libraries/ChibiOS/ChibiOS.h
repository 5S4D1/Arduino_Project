
#ifndef ChibiOS_h
#define ChibiOS_h
#include <utility/ch.h>
#include <utility/hal.h>
size_t chUnusedStack(void *wsp, size_t size);
#endif  // ChibiOS_h
